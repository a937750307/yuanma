
if (window.console&&window.console.log){  
	console.log("%c晨风网址发布页V1.0","color:#19a334");
	console.log("%c源码发布网址:xjks.top","color:#19a334");
}  

